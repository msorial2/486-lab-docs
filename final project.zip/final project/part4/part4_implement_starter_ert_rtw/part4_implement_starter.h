/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * File: part4_implement_starter.h
 *
 * Code generated for Simulink model 'part4_implement_starter'.
 *
 * Model version                  : 9.26
 * Simulink Coder version         : 24.2 (R2024b) 21-Jun-2024
 * C/C++ source code generated on : Wed Dec  3 15:57:53 2025
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Texas Instruments->C2000
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef part4_implement_starter_h_
#define part4_implement_starter_h_
#ifndef part4_implement_starter_COMMON_INCLUDES_
#define part4_implement_starter_COMMON_INCLUDES_
#include "rtwtypes.h"
#include "rtw_extmode.h"
#include "sysran_types.h"
#include "rtw_continuous.h"
#include "rtw_solver.h"
#include "ext_mode.h"
#include "c2000BoardSupport.h"
#include "MW_f2837xD_includes.h"
#include "IQmathLib.h"
#endif                            /* part4_implement_starter_COMMON_INCLUDES_ */

#include "part4_implement_starter_types.h"
#include "rt_zcfcn.h"
#include <string.h>
#include "zero_crossing_types.h"
#include "MW_target_hardware_resources.h"

/* Macros for accessing real-time model data structure */
#ifndef rtmGetContStateDisabled
#define rtmGetContStateDisabled(rtm)   ((rtm)->contStateDisabled)
#endif

#ifndef rtmSetContStateDisabled
#define rtmSetContStateDisabled(rtm, val) ((rtm)->contStateDisabled = (val))
#endif

#ifndef rtmGetContStates
#define rtmGetContStates(rtm)          ((rtm)->contStates)
#endif

#ifndef rtmSetContStates
#define rtmSetContStates(rtm, val)     ((rtm)->contStates = (val))
#endif

#ifndef rtmGetContTimeOutputInconsistentWithStateAtMajorStepFlag
#define rtmGetContTimeOutputInconsistentWithStateAtMajorStepFlag(rtm) ((rtm)->CTOutputIncnstWithState)
#endif

#ifndef rtmSetContTimeOutputInconsistentWithStateAtMajorStepFlag
#define rtmSetContTimeOutputInconsistentWithStateAtMajorStepFlag(rtm, val) ((rtm)->CTOutputIncnstWithState = (val))
#endif

#ifndef rtmGetDerivCacheNeedsReset
#define rtmGetDerivCacheNeedsReset(rtm) ((rtm)->derivCacheNeedsReset)
#endif

#ifndef rtmSetDerivCacheNeedsReset
#define rtmSetDerivCacheNeedsReset(rtm, val) ((rtm)->derivCacheNeedsReset = (val))
#endif

#ifndef rtmGetFinalTime
#define rtmGetFinalTime(rtm)           ((rtm)->Timing.tFinal)
#endif

#ifndef rtmGetIntgData
#define rtmGetIntgData(rtm)            ((rtm)->intgData)
#endif

#ifndef rtmSetIntgData
#define rtmSetIntgData(rtm, val)       ((rtm)->intgData = (val))
#endif

#ifndef rtmGetOdeF
#define rtmGetOdeF(rtm)                ((rtm)->odeF)
#endif

#ifndef rtmSetOdeF
#define rtmSetOdeF(rtm, val)           ((rtm)->odeF = (val))
#endif

#ifndef rtmGetPeriodicContStateIndices
#define rtmGetPeriodicContStateIndices(rtm) ((rtm)->periodicContStateIndices)
#endif

#ifndef rtmSetPeriodicContStateIndices
#define rtmSetPeriodicContStateIndices(rtm, val) ((rtm)->periodicContStateIndices = (val))
#endif

#ifndef rtmGetPeriodicContStateRanges
#define rtmGetPeriodicContStateRanges(rtm) ((rtm)->periodicContStateRanges)
#endif

#ifndef rtmSetPeriodicContStateRanges
#define rtmSetPeriodicContStateRanges(rtm, val) ((rtm)->periodicContStateRanges = (val))
#endif

#ifndef rtmGetRTWExtModeInfo
#define rtmGetRTWExtModeInfo(rtm)      ((rtm)->extModeInfo)
#endif

#ifndef rtmGetZCCacheNeedsReset
#define rtmGetZCCacheNeedsReset(rtm)   ((rtm)->zCCacheNeedsReset)
#endif

#ifndef rtmSetZCCacheNeedsReset
#define rtmSetZCCacheNeedsReset(rtm, val) ((rtm)->zCCacheNeedsReset = (val))
#endif

#ifndef rtmGetdX
#define rtmGetdX(rtm)                  ((rtm)->derivs)
#endif

#ifndef rtmSetdX
#define rtmSetdX(rtm, val)             ((rtm)->derivs = (val))
#endif

#ifndef rtmGetErrorStatus
#define rtmGetErrorStatus(rtm)         ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
#define rtmSetErrorStatus(rtm, val)    ((rtm)->errorStatus = (val))
#endif

#ifndef rtmGetStopRequested
#define rtmGetStopRequested(rtm)       ((rtm)->Timing.stopRequestedFlag)
#endif

#ifndef rtmSetStopRequested
#define rtmSetStopRequested(rtm, val)  ((rtm)->Timing.stopRequestedFlag = (val))
#endif

#ifndef rtmGetStopRequestedPtr
#define rtmGetStopRequestedPtr(rtm)    (&((rtm)->Timing.stopRequestedFlag))
#endif

#ifndef rtmGetT
#define rtmGetT(rtm)                   (rtmGetTPtr((rtm))[0])
#endif

#ifndef rtmGetTFinal
#define rtmGetTFinal(rtm)              ((rtm)->Timing.tFinal)
#endif

#ifndef rtmGetTPtr
#define rtmGetTPtr(rtm)                ((rtm)->Timing.t)
#endif

#ifndef rtmGetTStart
#define rtmGetTStart(rtm)              ((rtm)->Timing.tStart)
#endif

extern void config_ePWMSyncSource(void);
extern void config_ePWM_GPIO (void);
extern void config_ePWM_TBSync (void);
extern void config_ePWM_XBAR(void);

/* Block signals (default storage) */
typedef struct {
  real_T theta_r;                      /* '<Root>/Sum' */
  real_T theta_p;                      /* '<Root>/Sum1' */
  real_T TmpSignalConversionAtStateSpace[3];
  real_T TmpSignalConversionAtStateSpa_h[3];
  real_T In1;                          /* '<S2>/In1' */
  real_T PulseGenerator;               /* '<Root>/Pulse Generator' */
  real_T Switch1;                      /* '<Root>/Switch1' */
  int32_T eQEP;                        /* '<S1>/eQEP' */
  int32_T eQEP1;                       /* '<S1>/eQEP1' */
  boolean_T OR;                        /* '<S1>/OR' */
} B_part4_implement_starter_T;

/* Block states (default storage) for system '<Root>' */
typedef struct {
  int32_T clockTickCounter;            /* '<Root>/Pulse Generator' */
  int32_T GPIO31_FRAC_LEN;             /* '<Root>/GPIO31' */
  int32_T GPIO34_FRAC_LEN;             /* '<Root>/GPIO34' */
  int16_T TriggeredSubsystem_SubsysRanBC;/* '<S1>/Triggered Subsystem' */
} DW_part4_implement_starter_T;

/* Continuous states (default storage) */
typedef struct {
  real_T StateSpace2_CSTATE[4];        /* '<Root>/State-Space2' */
  real_T StateSpace_CSTATE[4];         /* '<Root>/State-Space' */
} X_part4_implement_starter_T;

/* State derivatives (default storage) */
typedef struct {
  real_T StateSpace2_CSTATE[4];        /* '<Root>/State-Space2' */
  real_T StateSpace_CSTATE[4];         /* '<Root>/State-Space' */
} XDot_part4_implement_starter_T;

/* State disabled  */
typedef struct {
  boolean_T StateSpace2_CSTATE[4];     /* '<Root>/State-Space2' */
  boolean_T StateSpace_CSTATE[4];      /* '<Root>/State-Space' */
} XDis_part4_implement_starter_T;

/* Zero-crossing (trigger) state */
typedef struct {
  ZCSigState TriggeredSubsystem_Trig_ZCE;/* '<S1>/Triggered Subsystem' */
} PrevZCX_part4_implement_start_T;

#ifndef ODE1_INTG
#define ODE1_INTG

/* ODE1 Integration Data */
typedef struct {
  real_T *f[1];                        /* derivatives */
} ODE1_IntgData;

#endif

/* Constant parameters (default storage) */
typedef struct {
  /* Expression: A - (L_5b*C)
   * Referenced by: '<Root>/State-Space'
   */
  real_T StateSpace_rtw_collapsed_sub_ex[16];

  /* Expression: A - (L*C)
   * Referenced by: '<Root>/State-Space2'
   */
  real_T StateSpace2_rtw_collapsed_sub_e[16];
} ConstP_part4_implement_starte_T;

/* Parameters (default storage) */
struct P_part4_implement_starter_T_ {
  real_T A[16];                        /* Variable: A
                                        * Referenced by:
                                        *   '<Root>/State-Space'
                                        *   '<Root>/State-Space2'
                                        */
  real_T K[4];                         /* Variable: K
                                        * Referenced by:
                                        *   '<Root>/Gain10'
                                        *   '<Root>/Gain11'
                                        *   '<Root>/Gain12'
                                        */
  real_T StartStop___PWM;              /* Variable: StartStop___PWM
                                        * Referenced by:
                                        *   '<Root>/Constant2'
                                        *   '<Root>/Constant7'
                                        */
  real_T Saturation_UpperSat;          /* Expression: 10
                                        * Referenced by: '<Root>/Saturation'
                                        */
  real_T Saturation_LowerSat;          /* Expression: -10
                                        * Referenced by: '<Root>/Saturation'
                                        */
  real_T Gain3_Gain;                   /* Expression: -1
                                        * Referenced by: '<Root>/Gain3'
                                        */
  real_T Out1_Y0;                      /* Computed Parameter: Out1_Y0
                                        * Referenced by: '<S2>/Out1'
                                        */
  real_T Constant3_Value;              /* Expression: 1
                                        * Referenced by: '<Root>/Constant3'
                                        */
  real_T Pi_Value;                     /* Expression: 0
                                        * Referenced by: '<Root>/Pi'
                                        */
  real_T Zero_Value;                   /* Expression: pi
                                        * Referenced by: '<Root>/Zero'
                                        */
  real_T StateSpace2_B[12];            /* Expression: [B L]
                                        * Referenced by: '<Root>/State-Space2'
                                        */
  real_T StateSpace2_C[16];            /* Expression: eye(4)
                                        * Referenced by: '<Root>/State-Space2'
                                        */
  real_T StateSpace2_InitialCondition[4];/* Expression: [0;0;pi;0]
                                          * Referenced by: '<Root>/State-Space2'
                                          */
  real_T PulseGenerator_Amp;           /* Expression: 1
                                        * Referenced by: '<Root>/Pulse Generator'
                                        */
  real_T PulseGenerator_Period;     /* Computed Parameter: PulseGenerator_Period
                                     * Referenced by: '<Root>/Pulse Generator'
                                     */
  real_T PulseGenerator_Duty;         /* Computed Parameter: PulseGenerator_Duty
                                       * Referenced by: '<Root>/Pulse Generator'
                                       */
  real_T PulseGenerator_PhaseDelay;    /* Expression: 0
                                        * Referenced by: '<Root>/Pulse Generator'
                                        */
  real_T Switch1_Threshold;            /* Expression: 0
                                        * Referenced by: '<Root>/Switch1'
                                        */
  real_T phi_p_Gain_Gain;              /* Expression: -(2*pi)/5000
                                        * Referenced by: '<Root>/phi_p_Gain'
                                        */
  real_T phi_r_Gain_Gain;              /* Expression: (2*pi)/4000
                                        * Referenced by: '<Root>/phi_r_Gain'
                                        */
  real_T Switch_Threshold;             /* Expression: 0
                                        * Referenced by: '<Root>/Switch'
                                        */
  real_T Constant6_Value;              /* Expression: 0
                                        * Referenced by: '<S1>/Constant6'
                                        */
  real_T Constant9_Value;              /* Expression: 0
                                        * Referenced by: '<Root>/Constant9'
                                        */
  real_T Gain_Gain;                    /* Expression: 250
                                        * Referenced by: '<S1>/Gain'
                                        */
  real_T Constant5_Value;              /* Expression: 2500
                                        * Referenced by: '<S1>/Constant5'
                                        */
  real_T Constant8_Value;              /* Expression: 1
                                        * Referenced by: '<S1>/Constant8'
                                        */
  real_T StateSpace_B[12];             /* Expression: [B L_5b]
                                        * Referenced by: '<Root>/State-Space'
                                        */
  real_T StateSpace_C[16];             /* Expression: eye(4)
                                        * Referenced by: '<Root>/State-Space'
                                        */
  real_T StateSpace_InitialCondition;  /* Expression: 0
                                        * Referenced by: '<Root>/State-Space'
                                        */
};

/* Real-time Model Data Structure */
struct tag_RTM_part4_implement_start_T {
  const char_T *errorStatus;
  RTWExtModeInfo *extModeInfo;
  RTWSolverInfo solverInfo;
  X_part4_implement_starter_T *contStates;
  int_T *periodicContStateIndices;
  real_T *periodicContStateRanges;
  real_T *derivs;
  XDis_part4_implement_starter_T *contStateDisabled;
  boolean_T zCCacheNeedsReset;
  boolean_T derivCacheNeedsReset;
  boolean_T CTOutputIncnstWithState;
  real_T odeF[1][8];
  ODE1_IntgData intgData;

  /*
   * Sizes:
   * The following substructure contains sizes information
   * for many of the model attributes such as inputs, outputs,
   * dwork, sample times, etc.
   */
  struct {
    uint32_T checksums[4];
    int_T numContStates;
    int_T numPeriodicContStates;
    int_T numSampTimes;
  } Sizes;

  /*
   * SpecialInfo:
   * The following substructure contains special information
   * related to other components that are dependent on RTW.
   */
  struct {
    const void *mappingInfo;
  } SpecialInfo;

  /*
   * Timing:
   * The following substructure contains information regarding
   * the timing information for the model.
   */
  struct {
    uint32_T clockTick0;
    time_T stepSize0;
    uint32_T clockTick1;
    time_T tStart;
    time_T tFinal;
    SimTimeStep simTimeStep;
    boolean_T stopRequestedFlag;
    time_T *t;
    time_T tArray[2];
  } Timing;
};

/* Block parameters (default storage) */
extern P_part4_implement_starter_T part4_implement_starter_P;

/* Block signals (default storage) */
extern B_part4_implement_starter_T part4_implement_starter_B;

/* Continuous states (default storage) */
extern X_part4_implement_starter_T part4_implement_starter_X;

/* Disabled states (default storage) */
extern XDis_part4_implement_starter_T part4_implement_starter_XDis;

/* Block states (default storage) */
extern DW_part4_implement_starter_T part4_implement_starter_DW;

/* Zero-crossing (trigger) state */
extern PrevZCX_part4_implement_start_T part4_implement_starter_PrevZCX;

/* Constant parameters (default storage) */
extern const ConstP_part4_implement_starte_T part4_implement_starter_ConstP;

/* Model entry point functions */
extern void part4_implement_starter_initialize(void);
extern void part4_implement_starter_step(void);
extern void part4_implement_starter_terminate(void);

/* Real-time Model object */
extern RT_MODEL_part4_implement_star_T *const part4_implement_starter_M;
extern volatile boolean_T stopRequested;
extern volatile boolean_T runModel;

/*-
 * These blocks were eliminated from the model due to optimizations:
 *
 * Block '<Root>/Gain1' : Unused code path elimination
 * Block '<Root>/Gain2' : Unused code path elimination
 * Block '<Root>/Gain4' : Unused code path elimination
 * Block '<Root>/Sum3' : Unused code path elimination
 */

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'part4_implement_starter'
 * '<S1>'   : 'part4_implement_starter/Reaction Wheel '
 * '<S2>'   : 'part4_implement_starter/Reaction Wheel /Triggered Subsystem'
 */
#endif                                 /* part4_implement_starter_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
