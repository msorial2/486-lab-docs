/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * File: part4_implement_starter_data.c
 *
 * Code generated for Simulink model 'part4_implement_starter'.
 *
 * Model version                  : 9.26
 * Simulink Coder version         : 24.2 (R2024b) 21-Jun-2024
 * C/C++ source code generated on : Wed Dec  3 15:57:53 2025
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Texas Instruments->C2000
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "part4_implement_starter.h"

/* Block parameters (default storage) */
P_part4_implement_starter_T part4_implement_starter_P = {
  /* Variable: A
   * Referenced by:
   *   '<Root>/State-Space'
   *   '<Root>/State-Space2'
   */
  { 0.0, 77.545635999999988, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 1.0, 0.0 },

  /* Variable: K
   * Referenced by:
   *   '<Root>/Gain10'
   *   '<Root>/Gain11'
   *   '<Root>/Gain12'
   */
  { -233.64906209645503, -21.364547404873253, 0.0, -0.025076852714602454 },

  /* Variable: StartStop___PWM
   * Referenced by:
   *   '<Root>/Constant2'
   *   '<Root>/Constant7'
   */
  1.0,

  /* Expression: 10
   * Referenced by: '<Root>/Saturation'
   */
  10.0,

  /* Expression: -10
   * Referenced by: '<Root>/Saturation'
   */
  -10.0,

  /* Expression: -1
   * Referenced by: '<Root>/Gain3'
   */
  -1.0,

  /* Computed Parameter: Out1_Y0
   * Referenced by: '<S2>/Out1'
   */
  0.0,

  /* Expression: 1
   * Referenced by: '<Root>/Constant3'
   */
  1.0,

  /* Expression: 0
   * Referenced by: '<Root>/Pi'
   */
  0.0,

  /* Expression: pi
   * Referenced by: '<Root>/Zero'
   */
  3.1415926535897931,

  /* Expression: [B L]
   * Referenced by: '<Root>/State-Space2'
   */
  { 0.0, -0.8519, 0.0, 187.4421, 89.999999999999943, 2163.2956359999826, 0.0,
    0.0, 0.0, 0.0, 84.99999999999828, 1799.9999999999345 },

  /* Expression: eye(4)
   * Referenced by: '<Root>/State-Space2'
   */
  { 1.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0,
    1.0 },

  /* Expression: [0;0;pi;0]
   * Referenced by: '<Root>/State-Space2'
   */
  { 0.0, 0.0, 3.1415926535897931, 0.0 },

  /* Expression: 1
   * Referenced by: '<Root>/Pulse Generator'
   */
  1.0,

  /* Computed Parameter: PulseGenerator_Period
   * Referenced by: '<Root>/Pulse Generator'
   */
  500.0,

  /* Computed Parameter: PulseGenerator_Duty
   * Referenced by: '<Root>/Pulse Generator'
   */
  250.0,

  /* Expression: 0
   * Referenced by: '<Root>/Pulse Generator'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<Root>/Switch1'
   */
  0.0,

  /* Expression: -(2*pi)/5000
   * Referenced by: '<Root>/phi_p_Gain'
   */
  -0.0012566370614359172,

  /* Expression: (2*pi)/4000
   * Referenced by: '<Root>/phi_r_Gain'
   */
  0.0015707963267948967,

  /* Expression: 0
   * Referenced by: '<Root>/Switch'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S1>/Constant6'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<Root>/Constant9'
   */
  0.0,

  /* Expression: 250
   * Referenced by: '<S1>/Gain'
   */
  250.0,

  /* Expression: 2500
   * Referenced by: '<S1>/Constant5'
   */
  2500.0,

  /* Expression: 1
   * Referenced by: '<S1>/Constant8'
   */
  1.0,

  /* Expression: [B L_5b]
   * Referenced by: '<Root>/State-Space'
   */
  { 0.0, -0.8519, 0.0, 187.4421, 85.342812585844513, 1902.3189697658861,
    -7.2431799983896079, -330.27528274865819, 4.6924128356213171,
    177.02943082685653, 89.657187414152745, 2025.3921329786056 },

  /* Expression: eye(4)
   * Referenced by: '<Root>/State-Space'
   */
  { 1.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0,
    1.0 },

  /* Expression: 0
   * Referenced by: '<Root>/State-Space'
   */
  0.0
};

/* Constant parameters (default storage) */
const ConstP_part4_implement_starte_T part4_implement_starter_ConstP = {
  /* Expression: A - (L_5b*C)
   * Referenced by: '<Root>/State-Space'
   */
  { 85.342812585844513, 1902.3189697658861, -7.2431799983896079,
    -330.27528274865819, 0.0, 0.0, 0.0, 0.0, 4.6924128356213171,
    177.02943082685653, 89.657187414152745, 2025.3921329786056, 0.0, 0.0, 0.0,
    0.0 },

  /* Expression: A - (L*C)
   * Referenced by: '<Root>/State-Space2'
   */
  { 89.999999999999943, 2163.2956359999826, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 84.99999999999828, 1799.9999999999345, 0.0, 0.0, 0.0, 0.0 }
};

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
