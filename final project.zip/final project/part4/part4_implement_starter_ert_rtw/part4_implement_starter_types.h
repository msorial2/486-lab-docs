/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * File: part4_implement_starter_types.h
 *
 * Code generated for Simulink model 'part4_implement_starter'.
 *
 * Model version                  : 9.26
 * Simulink Coder version         : 24.2 (R2024b) 21-Jun-2024
 * C/C++ source code generated on : Wed Dec  3 15:57:53 2025
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Texas Instruments->C2000
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef part4_implement_starter_types_h_
#define part4_implement_starter_types_h_

/* Parameters (default storage) */
typedef struct P_part4_implement_starter_T_ P_part4_implement_starter_T;

/* Forward declaration for rtModel */
typedef struct tag_RTM_part4_implement_start_T RT_MODEL_part4_implement_star_T;

#endif                                 /* part4_implement_starter_types_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
