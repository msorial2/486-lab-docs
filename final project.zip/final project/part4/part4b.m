a = 8.806^2;    %77.5522
bp = 0.8519;
br = 187.4421;

A = [0, 1, 0, 0;
    a, 0, 0, 0;
    0, 0, 0, 1;
    0, 0, 0, 0];
B = [0; -bp; 0; br]

%A = [0, 1; a, 0];
%B = [0; -bp];

R = ctrb(A,B)
R_rank = rank(R)

zeta = 1/sqrt(2);
zeta=0.5;
w=9;

s = tf('s');
sys1 = w^2 / (s^2 + 2*zeta*w*s + w^2);
poles = pole(sys1)

%part c
four_poles = zeros([4 1]);
four_poles(1:2) = poles;
four_poles(4) = -4.5;
K = place(A,B,four_poles);

C = [1 0 0 0;
     0 0 1 0];
new_poles = (real(four_poles)*10) + j*imag(four_poles);
new_poles(3) = -40;

A1 = A(1:2,1:2);
A2 = A(3:4, 3:4);
C1 = C(1, 1:2);
C2 = C(2, 3:4);

L_5b = place(A', C', new_poles).';
L1 = place(A1', C1', new_poles(1:2)).';
L2 = place(A2', C2', new_poles(3:4)).';
L = [L1 zeros([2 1]);
    zeros([2 1]) L2];
L_old_zeroed = [L_5b(1:2,1) zeros([2 1]);
    zeros([2 1]) L_5b(3:4,2)];

%K = place(A,B,poles)
%mat = A - B*K
%eig(mat)

